import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Float, MeshDistortMaterial, Sphere, Box, Cylinder, Torus } from "@react-three/drei";
import * as THREE from "three";

function BuildingStructure({ position }: { position: [number, number, number] }) {
  const groupRef = useRef<THREE.Group>(null!);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.05;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Main tower */}
      <Box args={[0.5, 3, 0.5]} position={[0, 1.5, 0]}>
        <meshStandardMaterial color="#1e3a5f" metalness={0.8} roughness={0.2} />
      </Box>
      {/* Building floors */}
      {[0, 0.6, 1.2, 1.8, 2.4].map((y, i) => (
        <Box key={i} args={[0.6, 0.05, 0.6]} position={[0, y, 0]}>
          <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.1} />
        </Box>
      ))}
      {/* Antenna */}
      <Cylinder args={[0.02, 0.02, 0.8, 8]} position={[0, 3.4, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.3} />
      </Cylinder>
    </group>
  );
}

function Crane({ position }: { position: [number, number, number] }) {
  const craneRef = useRef<THREE.Group>(null!);
  
  useFrame((state) => {
    if (craneRef.current) {
      craneRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
  });

  return (
    <group ref={craneRef} position={position}>
      {/* Vertical mast */}
      <Box args={[0.1, 4, 0.1]} position={[0, 2, 0]}>
        <meshStandardMaterial color="#4a5568" metalness={0.7} roughness={0.3} />
      </Box>
      {/* Horizontal jib */}
      <Box args={[3, 0.1, 0.1]} position={[0.5, 4, 0]}>
        <meshStandardMaterial color="#4a5568" metalness={0.7} roughness={0.3} />
      </Box>
      {/* Counter jib */}
      <Box args={[1, 0.1, 0.1]} position={[-0.8, 3.9, 0]}>
        <meshStandardMaterial color="#4a5568" metalness={0.7} roughness={0.3} />
      </Box>
      {/* Hook cable */}
      <Cylinder args={[0.02, 0.02, 1.5, 8]} position={[1.5, 3.25, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.2} />
      </Cylinder>
      {/* Hook */}
      <Torus args={[0.1, 0.03, 8, 16, Math.PI]} position={[1.5, 2.5, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.3} />
      </Torus>
    </group>
  );
}

function FloatingParticles() {
  const count = 80;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return pos;
  }, []);

  const particlesRef = useRef<THREE.Points>(null!);

  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.05} color="#d4a017" transparent opacity={0.6} />
    </points>
  );
}

function GroundGrid() {
  const gridRef = useRef<THREE.GridHelper>(null!);

  useFrame((state) => {
    if (gridRef.current) {
      gridRef.current.position.z = (state.clock.elapsedTime * 0.5) % 1;
    }
  });

  return (
    <gridHelper
      ref={gridRef}
      args={[30, 30, "#1e3a5f", "#1e3a5f"]}
      position={[0, -1, 0]}
    />
  );
}

function CentralSphere() {
  return (
    <Float speed={1.5} rotationIntensity={0.5} floatIntensity={0.5}>
      <Sphere args={[0.8, 64, 64]} position={[0, 0.5, 0]}>
        <MeshDistortMaterial
          color="#1e3a5f"
          metalness={0.9}
          roughness={0.1}
          distort={0.3}
          speed={2}
          emissive="#0a1929"
          emissiveIntensity={0.2}
        />
      </Sphere>
      {/* Gold ring around sphere */}
      <Torus args={[1.1, 0.04, 16, 100]} position={[0, 0.5, 0]} rotation={[Math.PI / 4, 0, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.05} emissive="#d4a017" emissiveIntensity={0.4} />
      </Torus>
    </Float>
  );
}

export default function HeroScene() {
  return (
    <Canvas
      camera={{ position: [8, 5, 12], fov: 45 }}
      style={{ width: "100%", height: "100%" }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.3} />
      <directionalLight position={[10, 10, 5]} intensity={1.5} color="#ffffff" castShadow />
      <pointLight position={[-5, 5, -5]} intensity={0.8} color="#1a56b0" />
      <pointLight position={[5, -2, 5]} intensity={0.6} color="#d4a017" />
      <spotLight position={[0, 10, 0]} intensity={1} color="#d4a017" angle={0.4} penumbra={0.5} />

      <FloatingParticles />
      <GroundGrid />
      <CentralSphere />
      
      <BuildingStructure position={[-4, -1, -2]} />
      <BuildingStructure position={[4, -1, -3]} />
      <BuildingStructure position={[-6, -1, 1]} />
      
      <Crane position={[2, -1, 1]} />
      <Crane position={[-2, -1, -4]} />

      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.5}
        maxPolarAngle={Math.PI / 2.2}
        minPolarAngle={Math.PI / 4}
      />
    </Canvas>
  );
}
