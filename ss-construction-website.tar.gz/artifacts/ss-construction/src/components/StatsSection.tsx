import { useEffect, useRef, useState } from "react";

const stats = [
  { value: 250, suffix: "+", label: "Projects Completed", icon: "🏗️" },
  { value: 15, suffix: "+", label: "Years Experience", icon: "📅" },
  { value: 98, suffix: "%", label: "Client Satisfaction", icon: "⭐" },
  { value: 500, suffix: "+", label: "Skilled Workers", icon: "👷" },
];

function Counter({ end, suffix }: { end: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null!);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const duration = 2000;
          const step = end / (duration / 16);
          let current = 0;
          const timer = setInterval(() => {
            current += step;
            if (current >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current));
            }
          }, 16);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end]);

  return (
    <span ref={ref} className="tabular-nums">
      {count}
      {suffix}
    </span>
  );
}

export default function StatsSection() {
  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-[hsl(220_15%_6%)] via-[hsl(215_35%_12%)] to-[hsl(220_15%_6%)]" />
      <div className="absolute inset-0 grid-bg opacity-30" />

      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(43_96%_56%)] to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(43_96%_56%)] to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <div
              key={i}
              className="relative text-center p-6 group"
            >
              {/* Corner brackets */}
              <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[hsl(43_96%_56%/0.5)] group-hover:border-[hsl(43_96%_56%)] transition-colors duration-300" />
              <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[hsl(43_96%_56%/0.5)] group-hover:border-[hsl(43_96%_56%)] transition-colors duration-300" />
              <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[hsl(43_96%_56%/0.5)] group-hover:border-[hsl(43_96%_56%)] transition-colors duration-300" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[hsl(43_96%_56%/0.5)] group-hover:border-[hsl(43_96%_56%)] transition-colors duration-300" />

              <div className="text-4xl mb-3 opacity-80">{stat.icon}</div>
              <div className="text-4xl lg:text-5xl font-black text-[hsl(43_96%_56%)] mb-2">
                <Counter end={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-sm text-[hsl(210_15%_55%)] tracking-wider font-medium uppercase">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
