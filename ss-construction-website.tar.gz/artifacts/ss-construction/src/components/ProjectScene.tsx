import { useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Box, Cylinder, Plane, RoundedBox } from "@react-three/drei";
import * as THREE from "three";

type ProjectType = "tower" | "bridge" | "complex";

interface Props {
  projectType: ProjectType;
}

function TowerBuilding() {
  const groupRef = useRef<THREE.Group>(null!);

  return (
    <group ref={groupRef}>
      {/* Foundation */}
      <Box args={[3, 0.2, 3]} position={[0, -1.9, 0]}>
        <meshStandardMaterial color="#2d3748" metalness={0.5} roughness={0.5} />
      </Box>
      {/* Main structure */}
      <Box args={[2, 4, 2]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#1e3a5f" metalness={0.7} roughness={0.2} />
      </Box>
      {/* Glass facade */}
      {[-0.5, 0, 0.5].map((x, xi) =>
        [-1.5, -0.8, -0.1, 0.6, 1.3].map((y, yi) => (
          <Box key={`${xi}-${yi}`} args={[0.35, 0.45, 0.02]} position={[x, y, 1.02]}>
            <meshStandardMaterial color="#4a90d9" metalness={0.9} roughness={0.1} transparent opacity={0.7} emissive="#1a4a8a" emissiveIntensity={0.3} />
          </Box>
        ))
      )}
      {/* Top structure */}
      <Box args={[1.5, 1.5, 1.5]} position={[0, 2.75, 0]}>
        <meshStandardMaterial color="#1e2d47" metalness={0.8} roughness={0.2} />
      </Box>
      {/* Antenna */}
      <Cylinder args={[0.04, 0.04, 1.5, 8]} position={[0, 4.25, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.05} emissive="#d4a017" emissiveIntensity={0.5} />
      </Cylinder>
      {/* Gold accent lines */}
      {[-1.5, -0.75, 0, 0.75, 1.5].map((y, i) => (
        <Box key={i} args={[2.05, 0.03, 2.05]} position={[0, y, 0]}>
          <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.2} />
        </Box>
      ))}
    </group>
  );
}

function BridgeModel() {
  return (
    <group>
      {/* Road deck */}
      <Box args={[6, 0.15, 1.5]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#2d3748" metalness={0.4} roughness={0.6} />
      </Box>
      {/* Main towers */}
      {[-2, 2].map((x, i) => (
        <group key={i} position={[x, 0, 0]}>
          <Cylinder args={[0.1, 0.1, 4, 8]} position={[0, 2, 0]}>
            <meshStandardMaterial color="#1e3a5f" metalness={0.8} roughness={0.2} />
          </Cylinder>
          <Box args={[0.8, 0.15, 0.2]} position={[0, 3.2, 0]}>
            <meshStandardMaterial color="#d4a017" metalness={1} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.2} />
          </Box>
        </group>
      ))}
      {/* Cables */}
      {[-2.5, -1.5, -0.5, 0.5, 1.5, 2.5].map((x, i) => (
        <group key={i}>
          <Cylinder args={[0.02, 0.02, 4, 4]} position={[x, 2, 0]} rotation={[0, 0, Math.atan2(4, Math.abs(x - (x < 0 ? -2 : 2)))  * (x < 0 ? -1 : 1)]}>
            <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.15} />
          </Cylinder>
        </group>
      ))}
      {/* Base pylons */}
      {[-2, 2].map((x, i) => (
        <Box key={i} args={[0.4, 0.6, 1.8]} position={[x, -0.4, 0]}>
          <meshStandardMaterial color="#374151" metalness={0.5} roughness={0.5} />
        </Box>
      ))}
    </group>
  );
}

function ComplexModel() {
  return (
    <group>
      {/* Central building */}
      <RoundedBox args={[2, 3, 2]} radius={0.05} position={[0, 0.5, 0]}>
        <meshStandardMaterial color="#1e3a5f" metalness={0.7} roughness={0.2} />
      </RoundedBox>
      {/* Side buildings */}
      <RoundedBox args={[1.2, 2, 1.2]} radius={0.05} position={[-1.8, 0, 0]}>
        <meshStandardMaterial color="#1e2d47" metalness={0.7} roughness={0.2} />
      </RoundedBox>
      <RoundedBox args={[1.2, 2.5, 1.2]} radius={0.05} position={[1.8, 0.25, 0]}>
        <meshStandardMaterial color="#162438" metalness={0.7} roughness={0.2} />
      </RoundedBox>
      {/* Connecting bridge */}
      <Box args={[1.4, 0.15, 0.8]} position={[-0.9, 1.2, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.2} />
      </Box>
      <Box args={[1.4, 0.15, 0.8]} position={[0.9, 1.5, 0]}>
        <meshStandardMaterial color="#d4a017" metalness={0.9} roughness={0.1} emissive="#d4a017" emissiveIntensity={0.2} />
      </Box>
      {/* Glass panels */}
      {[-0.5, 0.5].map((x, i) =>
        [-0.5, 0.3, 1.1].map((y, j) => (
          <Box key={`${i}-${j}`} args={[0.6, 0.5, 0.02]} position={[x, y, 1.02]}>
            <meshStandardMaterial color="#4a90d9" metalness={0.9} roughness={0.1} transparent opacity={0.6} emissive="#1a4a8a" emissiveIntensity={0.4} />
          </Box>
        ))
      )}
      {/* Ground plaza */}
      <Plane args={[6, 6]} rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, 0]}>
        <meshStandardMaterial color="#1a2030" metalness={0.3} roughness={0.7} />
      </Plane>
    </group>
  );
}

function SceneContent({ projectType }: { projectType: ProjectType }) {
  const groupRef = useRef<THREE.Group>(null!);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.003;
    }
  });

  return (
    <group ref={groupRef}>
      {projectType === "tower" && <TowerBuilding />}
      {projectType === "bridge" && <BridgeModel />}
      {projectType === "complex" && <ComplexModel />}
    </group>
  );
}

export default function ProjectScene({ projectType }: Props) {
  return (
    <Canvas
      camera={{ position: [6, 3, 6], fov: 45 }}
      style={{ width: "100%", height: "100%" }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 10, 5]} intensity={1.5} color="#ffffff" />
      <pointLight position={[-5, 5, -5]} intensity={0.8} color="#1a56b0" />
      <pointLight position={[5, -2, 5]} intensity={0.5} color="#d4a017" />
      <spotLight position={[0, 8, 0]} intensity={0.8} color="#d4a017" angle={0.5} penumbra={0.5} />

      <SceneContent projectType={projectType} />

      <OrbitControls
        enableZoom
        enablePan={false}
        autoRotate={false}
        maxPolarAngle={Math.PI / 1.8}
        minPolarAngle={Math.PI / 6}
      />
    </Canvas>
  );
}
