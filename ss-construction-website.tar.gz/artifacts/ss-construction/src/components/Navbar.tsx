import { useState, useEffect } from "react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Projects", href: "#projects" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      const sections = ["home", "about", "services", "projects", "contact"];
      for (const s of sections.reverse()) {
        const el = document.getElementById(s);
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActiveSection(s);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (href: string) => {
    const id = href.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
    setMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[hsl(220_15%_8%/0.95)] backdrop-blur-md border-b border-[hsl(215_20%_16%)]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => scrollTo("#home")}
          className="flex items-center gap-3 group"
        >
          <div className="relative w-9 h-9">
            <div className="absolute inset-0 bg-[hsl(43_96%_56%)] rounded-sm rotate-45 group-hover:rotate-[55deg] transition-transform duration-300" />
            <span className="absolute inset-0 flex items-center justify-center text-[hsl(220_15%_8%)] font-black text-sm z-10">SS</span>
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-white font-bold text-sm tracking-widest">SS CONSTRUCTION</span>
            <span className="text-[hsl(43_96%_56%)] text-[10px] tracking-[0.2em] font-medium">BUILD. INSPIRE. LAST.</span>
          </div>
        </button>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => scrollTo(link.href)}
              className={`relative text-sm font-medium tracking-wider transition-colors duration-200 group ${
                activeSection === link.href.replace("#", "")
                  ? "text-[hsl(43_96%_56%)]"
                  : "text-[hsl(210_20%_72%)] hover:text-white"
              }`}
            >
              {link.label}
              <span
                className={`absolute -bottom-1 left-0 h-px bg-[hsl(43_96%_56%)] transition-all duration-300 ${
                  activeSection === link.href.replace("#", "") ? "w-full" : "w-0 group-hover:w-full"
                }`}
              />
            </button>
          ))}
          <button
            onClick={() => scrollTo("#contact")}
            className="btn-shine ml-4 px-5 py-2 bg-[hsl(43_96%_56%)] text-[hsl(220_15%_8%)] text-sm font-bold tracking-wider rounded-sm hover:bg-[hsl(43_96%_65%)] transition-colors duration-200"
          >
            GET A QUOTE
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className={`block w-6 h-0.5 bg-[hsl(43_96%_56%)] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[hsl(43_96%_56%)] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`} />
          <span className={`block w-6 h-0.5 bg-[hsl(43_96%_56%)] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden transition-all duration-400 overflow-hidden ${
          menuOpen ? "max-h-80 opacity-100" : "max-h-0 opacity-0"
        } bg-[hsl(220_15%_9%/0.98)] backdrop-blur-md border-b border-[hsl(215_20%_16%)]`}
      >
        <div className="px-6 py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => scrollTo(link.href)}
              className={`text-left text-sm font-medium tracking-wider transition-colors ${
                activeSection === link.href.replace("#", "")
                  ? "text-[hsl(43_96%_56%)]"
                  : "text-[hsl(210_20%_72%)]"
              }`}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => scrollTo("#contact")}
            className="btn-shine w-full px-5 py-2.5 bg-[hsl(43_96%_56%)] text-[hsl(220_15%_8%)] text-sm font-bold tracking-wider rounded-sm"
          >
            GET A QUOTE
          </button>
        </div>
      </div>
    </nav>
  );
}
