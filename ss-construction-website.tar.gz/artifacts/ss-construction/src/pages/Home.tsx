import { lazy, Suspense, useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import StatsSection from "@/components/StatsSection";
import ProjectScene from "@/components/ProjectScene";
import ErrorBoundary from "@/components/ErrorBoundary";

const HeroScene = lazy(() => import("@/components/HeroScene"));

// Intersection observer hook for scroll animations
function useInView(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null!);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, inView };
}

// =========== HERO SECTION ===========
function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden hex-bg">
      {/* Deep gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-[hsl(220_15%_6%)] via-[hsl(220_15%_8%/0.8)] to-[hsl(215_35%_12%/0.6)]" />

      {/* 3D Scene */}
      <div className="absolute inset-0 z-0">
        <ErrorBoundary>
          <Suspense fallback={null}>
            <HeroScene />
          </Suspense>
        </ErrorBoundary>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-20">
        <div className="max-w-3xl">
          {/* Tag line */}
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
            <span className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.3em] uppercase">
              Est. 2009 — Premium Construction
            </span>
          </div>

          {/* Main heading */}
          <h1 className="text-5xl md:text-7xl font-black leading-[1.05] mb-6 tracking-tight">
            <span className="text-white block">BUILDING</span>
            <span className="gradient-text block">TOMORROW'S</span>
            <span className="text-white block">LANDMARKS</span>
          </h1>

          <p className="text-[hsl(210_15%_60%)] text-lg md:text-xl leading-relaxed mb-10 max-w-xl">
            SS Construction delivers world-class infrastructure, commercial complexes, and iconic structures with precision engineering and unwavering commitment to excellence.
          </p>

          <div className="flex flex-wrap gap-4">
            <a
              href="#projects"
              onClick={(e) => { e.preventDefault(); document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" }); }}
              className="btn-shine inline-flex items-center gap-3 px-8 py-4 bg-[hsl(43_96%_56%)] text-[hsl(220_15%_8%)] font-bold tracking-widest text-sm hover:bg-[hsl(43_96%_65%)] transition-all duration-300 rounded-sm glow-gold"
            >
              <span>VIEW PROJECTS</span>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
            <a
              href="#contact"
              onClick={(e) => { e.preventDefault(); document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" }); }}
              className="inline-flex items-center gap-3 px-8 py-4 border border-[hsl(215_20%_30%)] text-[hsl(210_20%_80%)] font-bold tracking-widest text-sm hover:border-[hsl(43_96%_56%)] hover:text-[hsl(43_96%_56%)] transition-all duration-300 rounded-sm"
            >
              GET A QUOTE
            </a>
          </div>

          {/* Scroll indicator */}
          <div className="mt-16 flex items-center gap-3">
            <div className="relative w-5 h-8 rounded-full border border-[hsl(215_20%_30%)] flex items-start justify-center pt-1.5">
              <div className="w-1 h-2 bg-[hsl(43_96%_56%)] rounded-full animate-bounce" />
            </div>
            <span className="text-[hsl(210_15%_40%)] text-xs tracking-widest uppercase">Scroll to explore</span>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-[hsl(220_15%_8%)] to-transparent" />
    </section>
  );
}

// =========== ABOUT SECTION ===========
function AboutSection() {
  const { ref, inView } = useInView();

  return (
    <section id="about" className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220_15%_8%)] to-[hsl(220_15%_10%)]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Content */}
          <div className={`transition-all duration-1000 ${inView ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}>
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
              <span className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.3em] uppercase">About Us</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-white leading-tight mb-6">
              BUILT ON
              <span className="gradient-text block">TRUST &</span>
              EXPERTISE
            </h2>
            <p className="text-[hsl(210_15%_58%)] text-lg leading-relaxed mb-6">
              SS Construction has been at the forefront of India's infrastructure revolution for over 15 years. From towering commercial skyscrapers to intricate civil engineering projects, we transform visions into enduring reality.
            </p>
            <p className="text-[hsl(210_15%_58%)] leading-relaxed mb-8">
              Our team of 500+ skilled professionals combines cutting-edge technology with time-tested craftsmanship, delivering projects that stand as testaments to human ingenuity and structural precision.
            </p>

            {/* Key points */}
            <div className="space-y-4">
              {[
                "ISO 9001:2015 Certified Excellence",
                "Advanced 3D BIM Technology Integration",
                "Zero-compromise Safety Standards",
                "Sustainable Green Building Practices",
              ].map((point, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-sm bg-[hsl(43_96%_56%/0.15)] border border-[hsl(43_96%_56%/0.5)] flex items-center justify-center flex-shrink-0">
                    <svg className="w-3 h-3 text-[hsl(43_96%_56%)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-[hsl(210_20%_75%)] text-sm">{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Visual */}
          <div className={`transition-all duration-1000 delay-200 ${inView ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}>
            <div className="relative">
              {/* Main card */}
              <div className="relative bg-[hsl(220_15%_11%)] border border-[hsl(215_20%_18%)] rounded-sm p-8 card-3d">
                {/* Inner glow */}
                <div className="absolute inset-0 rounded-sm bg-gradient-to-br from-[hsl(43_96%_56%/0.05)] to-transparent pointer-events-none" />

                {/* Blueprint-style schematic */}
                <div className="relative h-64 flex items-center justify-center">
                  {/* Blueprint grid */}
                  <div className="absolute inset-0 opacity-20"
                    style={{
                      backgroundImage: "linear-gradient(hsl(215 70% 50% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(215 70% 50% / 0.3) 1px, transparent 1px)",
                      backgroundSize: "20px 20px"
                    }}
                  />
                  
                  {/* Building outline */}
                  <svg viewBox="0 0 200 180" className="w-full h-full text-[hsl(215_70%_60%)]" fill="none">
                    {/* Main tower */}
                    <rect x="75" y="20" width="50" height="140" stroke="currentColor" strokeWidth="1.5" />
                    {/* Floor lines */}
                    {[40, 60, 80, 100, 120, 140].map(y => (
                      <line key={y} x1="75" y1={y} x2="125" y2={y} stroke="hsl(43 96% 56%)" strokeWidth="0.8" opacity="0.7" />
                    ))}
                    {/* Windows */}
                    {[0, 1, 2].map(xi =>
                      [0, 1, 2, 3, 4].map(yi => (
                        <rect key={`${xi}-${yi}`} x={82 + xi * 14} y={28 + yi * 22} width="8" height="12" fill="hsl(215 70% 60% / 0.3)" stroke="hsl(215 70% 70%)" strokeWidth="0.8" />
                      ))
                    )}
                    {/* Crane */}
                    <line x1="125" y1="20" x2="160" y2="20" stroke="hsl(43 96% 56%)" strokeWidth="1.5" />
                    <line x1="155" y1="20" x2="155" y2="60" stroke="hsl(43 96% 56%)" strokeWidth="1" strokeDasharray="4,2" />
                    <line x1="130" y1="15" x2="130" y2="60" stroke="currentColor" strokeWidth="1.5" />
                    {/* Ground */}
                    <line x1="20" y1="160" x2="180" y2="160" stroke="currentColor" strokeWidth="1.5" />
                    {/* Annotations */}
                    <text x="25" y="90" fill="hsl(43 96% 56%)" fontSize="7" fontFamily="monospace">H: 240m</text>
                    <text x="25" y="102" fill="hsl(43 96% 56%)" fontSize="7" fontFamily="monospace">F: 60</text>
                    <text x="135" y="90" fill="currentColor" fontSize="7" fontFamily="monospace">BIM v3</text>
                  </svg>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div>
                    <div className="text-[hsl(43_96%_56%)] font-mono text-xs tracking-wider">SS-BIM-2024</div>
                    <div className="text-[hsl(210_15%_40%)] text-xs">Structural Blueprint</div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-bold text-sm">APPROVED</div>
                    <div className="text-[hsl(43_96%_56%)] text-xs font-mono">✓ Certified</div>
                  </div>
                </div>
              </div>

              {/* Floating badge */}
              <div className="absolute -top-4 -right-4 bg-[hsl(43_96%_56%)] text-[hsl(220_15%_8%)] p-4 rounded-sm shadow-2xl">
                <div className="text-2xl font-black leading-none">15+</div>
                <div className="text-xs font-bold tracking-wider leading-none mt-1">YEARS</div>
              </div>

              {/* Bottom left badge */}
              <div className="absolute -bottom-4 -left-4 bg-[hsl(215_70%_45%)] text-white p-4 rounded-sm shadow-2xl animate-pulse-gold">
                <div className="text-xs font-bold tracking-wider">ISO CERTIFIED</div>
                <div className="text-xs opacity-75 mt-0.5">9001:2015</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// =========== SERVICES SECTION ===========
const services = [
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6" />
      </svg>
    ),
    title: "Commercial Construction",
    desc: "High-rise office towers, shopping complexes, and commercial hubs designed for maximum functionality and lasting impact.",
    highlight: "500+ projects delivered",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <path d="M12 22s-8-4.5-8-11.8A8 8 0 0112 2a8 8 0 018 8.2c0 7.3-8 11.8-8 11.8z" />
        <circle cx="12" cy="10" r="3" />
      </svg>
    ),
    title: "Infrastructure Development",
    desc: "Roads, bridges, flyovers, and public infrastructure that connects communities and drives economic growth.",
    highlight: "Pan-India presence",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <path d="M3 9h18M3 15h18M9 3v18M15 3v18" />
      </svg>
    ),
    title: "Residential Projects",
    desc: "Premium townships, luxury apartments, and integrated housing societies crafted for modern living excellence.",
    highlight: "10,000+ homes built",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
      </svg>
    ),
    title: "Industrial Facilities",
    desc: "State-of-the-art warehouses, manufacturing plants, and logistics hubs engineered for operational efficiency.",
    highlight: "50+ industrial projects",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <path d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18" />
      </svg>
    ),
    title: "Renovation & Retrofitting",
    desc: "Structural upgrades, seismic retrofitting, and comprehensive renovation to restore and enhance existing structures.",
    highlight: "200+ renovations done",
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth={1.5}>
        <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
      </svg>
    ),
    title: "Project Consultancy",
    desc: "End-to-end project management, structural design consultation, and feasibility studies for optimal outcomes.",
    highlight: "Expert advisory team",
  },
];

function ServicesSection() {
  const { ref, inView } = useInView();

  return (
    <section id="services" className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-[hsl(220_15%_9%)]" />
      <div className="absolute inset-0 grid-bg opacity-20" />

      {/* Accent lines */}
      <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[hsl(43_96%_56%/0.3)] to-transparent" />
      <div className="absolute right-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[hsl(215_70%_50%/0.3)] to-transparent" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className={`text-center mb-16 transition-all duration-800 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
            <span className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.3em] uppercase">Our Services</span>
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-white">
            WHAT WE <span className="gradient-text">BUILD</span>
          </h2>
          <p className="mt-4 text-[hsl(210_15%_55%)] max-w-2xl mx-auto">
            Comprehensive construction solutions engineered to the highest standards of quality, safety, and innovation.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <div
              key={i}
              className={`group relative bg-[hsl(220_15%_11%)] border border-[hsl(215_20%_16%)] p-8 hover:border-[hsl(43_96%_56%/0.4)] transition-all duration-500 card-3d ${
                inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              {/* Top accent */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(43_96%_56%/0)] to-transparent group-hover:via-[hsl(43_96%_56%/0.6)] transition-all duration-500" />

              {/* Icon */}
              <div className="mb-6 text-[hsl(43_96%_56%)] group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>

              <h3 className="text-white font-bold text-lg mb-3 group-hover:text-[hsl(43_96%_56%)] transition-colors duration-300">
                {service.title}
              </h3>
              <p className="text-[hsl(210_15%_52%)] text-sm leading-relaxed mb-4">{service.desc}</p>

              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-[hsl(43_96%_56%)] rounded-full" />
                <span className="text-[hsl(43_96%_56%)] text-xs font-medium tracking-wider">{service.highlight}</span>
              </div>

              {/* Corner decoration */}
              <div className="absolute bottom-3 right-3 w-6 h-6 border-b border-r border-[hsl(43_96%_56%/0.3)] group-hover:border-[hsl(43_96%_56%/0.6)] transition-colors duration-300" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// =========== PROJECTS SECTION ===========
type ProjectType = "tower" | "bridge" | "complex";

const projects: { id: number; title: string; location: string; type: string; year: number; value: string; model: ProjectType; desc: string }[] = [
  {
    id: 1,
    title: "Skyline Tower",
    location: "Mumbai, Maharashtra",
    type: "Commercial",
    year: 2023,
    value: "₹450 Cr",
    model: "tower",
    desc: "40-story glass-and-steel commercial skyscraper featuring cutting-edge sustainable design and LEED Platinum certification.",
  },
  {
    id: 2,
    title: "Gateway Bridge",
    location: "Pune-Mumbai Expressway",
    type: "Infrastructure",
    year: 2022,
    value: "₹280 Cr",
    model: "bridge",
    desc: "A 1.2 km six-lane cable-stayed bridge over the Indrayani River, reducing travel time by 45 minutes.",
  },
  {
    id: 3,
    title: "Corporate Park Alpha",
    location: "Hyderabad, Telangana",
    type: "Commercial Complex",
    year: 2024,
    value: "₹620 Cr",
    model: "complex",
    desc: "Integrated 15-acre corporate campus with three towers, convention center, and smart city infrastructure.",
  },
];

function ProjectsSection() {
  const { ref, inView } = useInView();
  const [active, setActive] = useState(0);
  const activeProject = projects[active];

  return (
    <section id="projects" className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220_15%_9%)] to-[hsl(220_15%_7%)]" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className={`mb-16 transition-all duration-800 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
            <span className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.3em] uppercase">Featured Projects</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-white">
            OUR <span className="gradient-text">LANDMARK</span> WORKS
          </h2>
          <p className="mt-4 text-[hsl(210_15%_55%)] max-w-xl">
            Interact with 3D models of our completed projects. Drag to rotate, scroll to zoom.
          </p>
        </div>

        <div className={`grid lg:grid-cols-5 gap-8 transition-all duration-1000 ${inView ? "opacity-100" : "opacity-0"}`}>
          {/* Project list */}
          <div className="lg:col-span-2 space-y-3">
            {projects.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setActive(i)}
                className={`w-full text-left p-5 border transition-all duration-300 group ${
                  active === i
                    ? "bg-[hsl(43_96%_56%/0.08)] border-[hsl(43_96%_56%/0.5)]"
                    : "bg-[hsl(220_15%_11%)] border-[hsl(215_20%_16%)] hover:border-[hsl(215_20%_25%)]"
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className={`font-bold text-sm transition-colors duration-200 ${active === i ? "text-[hsl(43_96%_56%)]" : "text-white group-hover:text-[hsl(43_96%_56%)]"}`}>
                      {p.title}
                    </div>
                    <div className="text-[hsl(210_15%_45%)] text-xs mt-0.5">{p.location}</div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-4">
                    <div className="text-[hsl(43_96%_56%)] text-xs font-bold">{p.value}</div>
                    <div className="text-[hsl(210_15%_40%)] text-xs">{p.year}</div>
                  </div>
                </div>
                <div className={`text-xs transition-colors duration-200 ${active === i ? "text-[hsl(215_70%_60%)]" : "text-[hsl(210_15%_40%)]"}`}>
                  {p.type}
                </div>
                {active === i && (
                  <div className="mt-3 text-[hsl(210_15%_55%)] text-xs leading-relaxed">
                    {p.desc}
                  </div>
                )}
              </button>
            ))}

            <div className="pt-4 flex items-center gap-2 text-[hsl(210_15%_40%)] text-xs">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 15l6-6m0 0l-6-6m6 6H9a6 6 0 000 12h3" />
              </svg>
              Drag model to rotate — scroll to zoom
            </div>
          </div>

          {/* 3D Viewer */}
          <div className="lg:col-span-3">
            <div className="relative bg-[hsl(220_15%_9%)] border border-[hsl(215_20%_16%)] rounded-sm overflow-hidden" style={{ height: 420 }}>
              {/* Status bar */}
              <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-4 py-2 bg-[hsl(220_15%_8%/0.9)] border-b border-[hsl(215_20%_16%)]">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[hsl(43_96%_56%)] rounded-full animate-pulse" />
                  <span className="text-[hsl(43_96%_56%)] font-mono text-xs tracking-wider">3D VIEWER ACTIVE</span>
                </div>
                <span className="text-[hsl(210_15%_40%)] font-mono text-xs">{activeProject.title.toUpperCase()}</span>
              </div>

              {/* Corner brackets */}
              <div className="absolute top-8 left-2 w-6 h-6 border-t border-l border-[hsl(43_96%_56%/0.5)] z-10 pointer-events-none" />
              <div className="absolute top-8 right-2 w-6 h-6 border-t border-r border-[hsl(43_96%_56%/0.5)] z-10 pointer-events-none" />
              <div className="absolute bottom-2 left-2 w-6 h-6 border-b border-l border-[hsl(43_96%_56%/0.5)] z-10 pointer-events-none" />
              <div className="absolute bottom-2 right-2 w-6 h-6 border-b border-r border-[hsl(43_96%_56%/0.5)] z-10 pointer-events-none" />

              <div className="absolute inset-0 pt-8">
                <ErrorBoundary fallback={
                  <div className="flex items-center justify-center h-full text-[hsl(210_15%_40%)] text-sm">
                    3D viewer unavailable
                  </div>
                }>
                  <ProjectScene projectType={activeProject.model} />
                </ErrorBoundary>
              </div>
            </div>

            {/* Project details */}
            <div className="mt-4 grid grid-cols-3 gap-3">
              {[
                { label: "Project Value", value: activeProject.value },
                { label: "Completed", value: activeProject.year.toString() },
                { label: "Category", value: activeProject.type },
              ].map((d, i) => (
                <div key={i} className="bg-[hsl(220_15%_11%)] border border-[hsl(215_20%_16%)] p-3 text-center">
                  <div className="text-[hsl(43_96%_56%)] font-bold text-sm">{d.value}</div>
                  <div className="text-[hsl(210_15%_40%)] text-xs mt-0.5">{d.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// =========== CONTACT SECTION ===========
function ContactSection() {
  const { ref, inView } = useInView();
  const [form, setForm] = useState({ name: "", email: "", phone: "", service: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setForm({ name: "", email: "", phone: "", service: "", message: "" });
  };

  return (
    <section id="contact" className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-[hsl(220_15%_7%)]" />
      <div className="absolute inset-0 hex-bg opacity-30" />

      {/* Gold line at top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(43_96%_56%)] to-transparent" />

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className={`text-center mb-16 transition-all duration-800 ${inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
            <span className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.3em] uppercase">Contact Us</span>
            <div className="h-px w-12 bg-[hsl(43_96%_56%)]" />
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-white">
            LET'S BUILD
            <span className="gradient-text block">SOMETHING GREAT</span>
          </h2>
          <p className="mt-4 text-[hsl(210_15%_55%)] max-w-xl mx-auto">
            Ready to bring your vision to life? Contact our team for a free consultation and project estimate.
          </p>
        </div>

        <div className={`grid lg:grid-cols-5 gap-12 transition-all duration-1000 ${inView ? "opacity-100" : "opacity-0"}`}>
          {/* Contact Info */}
          <div className="lg:col-span-2 space-y-8">
            {[
              {
                icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
                label: "Head Office",
                value: "SS Construction Tower, Plot 12, MIDC Industrial Area, Pune - 411019, Maharashtra",
              },
              {
                icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>,
                label: "Phone",
                value: "+91 20 4567 8900\n+91 98765 43210",
              },
              {
                icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
                label: "Email",
                value: "projects@ssconstruction.in\ninfo@ssconstruction.in",
              },
            ].map((item, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 bg-[hsl(43_96%_56%/0.1)] border border-[hsl(43_96%_56%/0.3)] flex items-center justify-center text-[hsl(43_96%_56%)] rounded-sm">
                  {item.icon}
                </div>
                <div>
                  <div className="text-[hsl(210_15%_45%)] text-xs tracking-wider mb-1">{item.label}</div>
                  <div className="text-white text-sm leading-relaxed whitespace-pre-line">{item.value}</div>
                </div>
              </div>
            ))}

            {/* Working hours */}
            <div className="bg-[hsl(220_15%_11%)] border border-[hsl(215_20%_16%)] p-5 rounded-sm">
              <div className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-wider mb-3">WORKING HOURS</div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[hsl(210_15%_55%)]">Mon – Sat</span>
                  <span className="text-white font-medium">9:00 AM – 7:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[hsl(210_15%_55%)]">Sunday</span>
                  <span className="text-[hsl(210_15%_40%)]">By Appointment</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <div className="bg-[hsl(220_15%_10%)] border border-[hsl(215_20%_16%)] p-8 rounded-sm">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 bg-[hsl(43_96%_56%/0.1)] border border-[hsl(43_96%_56%)] rounded-full flex items-center justify-center mb-4">
                    <svg className="w-8 h-8 text-[hsl(43_96%_56%)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-white font-bold text-xl mb-2">Message Sent!</h3>
                  <p className="text-[hsl(210_15%_55%)]">Our team will contact you within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[hsl(210_15%_50%)] text-xs tracking-wider mb-2">FULL NAME *</label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                        className="w-full bg-[hsl(220_15%_8%)] border border-[hsl(215_20%_20%)] text-white text-sm px-4 py-3 rounded-sm outline-none focus:border-[hsl(43_96%_56%)] transition-colors"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="block text-[hsl(210_15%_50%)] text-xs tracking-wider mb-2">EMAIL *</label>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                        className="w-full bg-[hsl(220_15%_8%)] border border-[hsl(215_20%_20%)] text-white text-sm px-4 py-3 rounded-sm outline-none focus:border-[hsl(43_96%_56%)] transition-colors"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[hsl(210_15%_50%)] text-xs tracking-wider mb-2">PHONE</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                        className="w-full bg-[hsl(220_15%_8%)] border border-[hsl(215_20%_20%)] text-white text-sm px-4 py-3 rounded-sm outline-none focus:border-[hsl(43_96%_56%)] transition-colors"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                    <div>
                      <label className="block text-[hsl(210_15%_50%)] text-xs tracking-wider mb-2">SERVICE TYPE</label>
                      <select
                        value={form.service}
                        onChange={e => setForm(f => ({ ...f, service: e.target.value }))}
                        className="w-full bg-[hsl(220_15%_8%)] border border-[hsl(215_20%_20%)] text-white text-sm px-4 py-3 rounded-sm outline-none focus:border-[hsl(43_96%_56%)] transition-colors"
                      >
                        <option value="">Select a service</option>
                        <option>Commercial Construction</option>
                        <option>Infrastructure Development</option>
                        <option>Residential Projects</option>
                        <option>Industrial Facilities</option>
                        <option>Renovation & Retrofitting</option>
                        <option>Project Consultancy</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[hsl(210_15%_50%)] text-xs tracking-wider mb-2">PROJECT DETAILS</label>
                    <textarea
                      rows={4}
                      value={form.message}
                      onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                      className="w-full bg-[hsl(220_15%_8%)] border border-[hsl(215_20%_20%)] text-white text-sm px-4 py-3 rounded-sm outline-none focus:border-[hsl(43_96%_56%)] transition-colors resize-none"
                      placeholder="Tell us about your project requirements..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn-shine w-full py-4 bg-[hsl(43_96%_56%)] text-[hsl(220_15%_8%)] font-bold tracking-widest text-sm hover:bg-[hsl(43_96%_65%)] transition-colors duration-200 rounded-sm"
                  >
                    SUBMIT INQUIRY
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// =========== FOOTER ===========
function Footer() {
  return (
    <footer className="relative border-t border-[hsl(215_20%_14%)] bg-[hsl(220_15%_6%)] py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-9 h-9">
                <div className="absolute inset-0 bg-[hsl(43_96%_56%)] rounded-sm rotate-45" />
                <span className="absolute inset-0 flex items-center justify-center text-[hsl(220_15%_8%)] font-black text-sm z-10">SS</span>
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-white font-bold text-sm tracking-widest">SS CONSTRUCTION</span>
                <span className="text-[hsl(43_96%_56%)] text-[10px] tracking-[0.2em] font-medium">BUILD. INSPIRE. LAST.</span>
              </div>
            </div>
            <p className="text-[hsl(210_15%_45%)] text-sm leading-relaxed max-w-xs">
              15+ years of delivering landmark construction projects across India with precision, quality, and innovation.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <div className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.2em] mb-4">QUICK LINKS</div>
            <div className="space-y-2">
              {["About Us", "Services", "Projects", "Contact", "Careers"].map(link => (
                <div key={link} className="text-[hsl(210_15%_45%)] text-sm hover:text-[hsl(43_96%_56%)] cursor-pointer transition-colors">{link}</div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <div className="text-[hsl(43_96%_56%)] text-xs font-bold tracking-[0.2em] mb-4">CERTIFICATIONS</div>
            <div className="space-y-2">
              {["ISO 9001:2015", "ISO 14001:2015", "OHSAS 18001", "LEED Certified", "BIS Certified"].map(cert => (
                <div key={cert} className="flex items-center gap-2">
                  <div className="w-1 h-1 bg-[hsl(43_96%_56%)] rounded-full" />
                  <span className="text-[hsl(210_15%_45%)] text-sm">{cert}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-[hsl(215_20%_12%)] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-[hsl(210_15%_35%)] text-xs">
            © {new Date().getFullYear()} SS Construction Pvt. Ltd. All rights reserved.
          </div>
          <div className="flex items-center gap-6 text-[hsl(210_15%_35%)] text-xs">
            <span className="hover:text-[hsl(43_96%_56%)] cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-[hsl(43_96%_56%)] cursor-pointer transition-colors">Terms of Use</span>
            <span className="hover:text-[hsl(43_96%_56%)] cursor-pointer transition-colors">Sitemap</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// =========== MAIN HOME ===========
export default function Home() {
  return (
    <div className="min-h-screen bg-[hsl(220_15%_8%)]">
      <Navbar />
      <HeroSection />
      <StatsSection />
      <AboutSection />
      <ServicesSection />
      <ProjectsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
